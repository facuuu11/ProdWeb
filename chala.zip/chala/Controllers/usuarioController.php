<?php namespace Controllers;

use Models\USUARIO as USUARIO;
use Models\CATEGORIAS as CATEGORIAS;
use Models\PRODUCTOS as PRODUCTOS;

class usuarioController{

private $usuario;
private $categorias;
private $productos;

public function __construct(){
$this->usuario = new USUARIO();
$this->categorias = new Categorias();
$this->productos = new PRODUCTOS();

}
public function index(){
$datos = $this->usuario->listar(); 
return $datos;

}
public function agregar(){
if (!$_POST) {
    $datos = $this->categorias->listar();

} 
}
public function agregar(){
if (!$_POST) {
$datos = $this->productos->listar();

}else{
$permitidos = array("image/jepg","image/png","image/gif","image/jpg");
$limite = 700;
if (in_array($_FILES['image']['type'], $permitidos &&  $_FILES['image']['size'] <= $limite * 1024)) {
$nombre = date('is'). $_FILES['image']['name'];   
$ruta = "Views" . DS . "_template" . DS . "imagenes" . DS . "avatars" . DS . $nombre;
move_uploaded_file($_FILES['image']['tmp_name'],$ruta);
$this->usuario->set("id_usauario", $_POST['id_usuario']);
$this->usuario->set("nombre", $_POST['nombre']);
$this->usuario->set("apellido", $_POST['apellido']);
$this->usuario->set("email", $_POST['email']);
$this->usuario->set("contraseña", $_POST['contraseña']);
$this->usuario->set("dni", $_POST['dni']);
$this->usario->edit();
header("Location:" . URL. "usario");
}



} 



}
public function editar($id){
if (!$_POST) {
$this->usuario->set("id_usuario", $_POST['id_usuario']);    
$this->usuario->set("nombre" , $_POST['nombre']);
$this->usurio->set("apellido", $_POST['apellido']);
$this->usuario->set("email", $_POST['email']);
$this->usuario->set("contraseña", $_POST['contraseña']);
$this->usuario->set("dni", $_POST['dni']);
$this->usuario->edit();
header("Location:" . URL . "usuario");
}

}

public function listarSecciones(){
  $datos = $this->Seccion-listar();  
return $datos;
}
public function ver($id){
$this->usuario->set("id",$id);
$datos = $this->usuario->view();
return $datos;
}
public function eliminar($id){
$this->usuario->set("id",$id);    
$this->usuario->delete();
header("Location:" . URL . "usuario");
}
}
$usuario = new usarioController();

?>