<?php namespace Controllers;
abstract class Controller{
   private $VISITA; 

public function __construct(Request $request);

}


?>