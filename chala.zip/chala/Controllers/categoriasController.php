<?php namespace Controllers;

use Models\CATEGORIAS as Categorias;

class categoriasController{

private $categorias;

public function __construct(){
$this->categorias = new seccion();
}
public function index(){
$datos = $this->categorias->listar();   
return $datos;
}

public function agragar(){
if ($_POST) {
$this->categorias->set("categorias", $_POST['categorias']);    
$this->categorias->add();
header("Location:" . URL . "categorias");   

}

}
public function editar($id){
if ($_POST) {
$this->categorias->set("id_categorias", $_POST['id_categorias']);
$this->categorias->set("categorias" . $_POST['categorias']);
$this->categorias->edit();
header("Location:" . URL . "categorias");
}else {
$this->categorias->set("id_categorias",$id);
$datos = $this->categorias->view();
return $datos;

}

}
public function eliminar($id){
$this->categorias->set("id",$id);
$this->categorias->delete();
header("Location:" . URL . "categorias");

}


}












?>