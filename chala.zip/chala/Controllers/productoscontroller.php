<?php namespace Controllers;
use Models\PRODUCTOS as Producto;

class productosController{
private $productos;

public function __construct(){
$this->productos = new Productos();

}
public function index(){
$datos = $this->productos-listar();  
return $datos;
}

public function agregar(){
if ($_POST) {
$this->productos->Set("nombreProducto", $_POST['nombreProducto']);    
$this->productos->add();
header("Location:" . URL . "productos");
}

}
public function editar($id){
if ($_POST) {
$this->productos->set("id_producto" , $_POST['id_producto']);
$this->productos->set("nombreProducto", $_POST['nombreProducto']);
$this->productos->set("precioproducto", $_POST['precioProdcuto']);
$this->productos->set("detalleProducto", $_POST['detalleProducto']);
$this->productos->set("categoriasProducto", $_POST['categoriasProducto']);
$this->productos->edit();
header("Location:" . URL . "productos");
}else{
$this->productos-set("id_productos",$id);    
$datos = $this->productos->view();
return $datos;
}


}
public function eliminar($id){
$this->productos->set("id",$id);
$this->productos->delete();
header("Location:" . URL . "productos");

}


}


?>