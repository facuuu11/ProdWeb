<?php namespace Views;

$template = new template();


    class template{

        public function __construct(){


?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina Inicio</title>
    <link rel="stylesheet" href="<?php echo URL;?>Views/css/boostrap.css  "  >
    <link rel="stylesheet" href="<?php echo URL;?>Views/css/general.css  "  >
</head>
<body>
    <h1>bienvenido a chala</h1>



    <?php  
       } 

       public function __destruct(){

      


   


    ?>
    <script src="<?php echo URL;   ?>Views/temlate/js/boostrap.js" ></script>
</body>
</html>


<?php 
 } 

} 
?>