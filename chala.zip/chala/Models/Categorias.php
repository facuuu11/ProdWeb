<?php namespace Models;

class Categorias{
    private $id_Categorias;
    private $categorias;


    private $con;

    public function __construct(){
        $this->con = new Conexion();
    }

   
    public function set($atributo,$contenido){
        $this->$atributo = $contenido;
    }

    public function get($atributo){
        return $this->$atributo;
    }



    
    public function listar(){
        $sql = "SELECT * FROM categorias";
        $datos = $this->con->consultaRetorno($sql);
        return $datos;

    }

    public function add(){
        $sql = "INSERT INTO categorias (id_Categorias,categorias) VALUES (null, '{$this->nombreProducto}')";
        $this->con->consultaSimple($sql);
    }


    public function delete(){
        $sql = "DELETE FROM categorias WHERE id_producto = '{$this->id_Categorias}'";
        $this->con->consultaSimple($sql);
    }


     public function edit(){
        $sql = "UPDATE categorias SET categorias = '{$this->$categorias}' WHERE  id = '{$this->id_Categorias}'";
        $this->con->consultaSimple($sql);
    }

    public function view(){
        $sql = "SELECT * FROM categorias WHERE $id_Categorias; = '{$this->id_Categorias}'";
            $datos = $this->con->consultaRetorno($sql);
            $row = mysqli_fetch_assoc($datos);
            return $row;
        }




}








?>