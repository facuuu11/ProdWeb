<?php namespace config;

class Enrutador{
public static function run(Request $requeset){
$controlador = $requeset->getControlador(). "Controller";    
$ruta = ROOT . "Controllers" . DS . $controlador . "php";

$metodo = $requeset->getMetodo();  

if ($metodo == "index.php"){
  $metodo = "index";  
}

$argumento = $requeset->getArgumento();

if (is_readable($ruta)) {
  require_once $Ruta;
$mostrar = "Controllers\\" . $controlador;
$controlador = new $mostrar;
if (!isset($argumento)) {
    $datos = call_user_func(array($controlador,$metodo), $argumento);
}
}

$ruta = ROOT . "Views" . DS . $requeset->getControlador() . DS . $requeset->getMetodo() . ".php";
if(is_readable($ruta)){
require_once $ruta;  
}else {
print "error 404";   
}
}
   
    
}





?>