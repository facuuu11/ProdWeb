<?php

define('DS', DIRECTORY_SEPARATOR);
define('ROOT', realpath(dirname(__FILE__)) .DS);

define('URL', "http://localhost/chala");

require_once "config/autoload.php";
config\Autoload::run();



require_once "Views/template/template.php";

Config\Enrutador::run(new config\Request());

?>